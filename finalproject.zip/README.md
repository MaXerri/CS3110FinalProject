Members: Name, netID, email
- Mario Xerri, max3, max3@cornell.edu
- Samuel F. Palomino, sfp58, sfp58@cornell.edu
- Lucas Silva, LAS495, las495@cornell.edu
- Jalen Jenkins, jjj85, jjj85@cornell.edu